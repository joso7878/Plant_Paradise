export const GlobalStyles = {
    colors: {
        primaryColor: '#418B64',
        primaryBg: '#fff',
        secondaryColor: '#969595',
        secondaryBg: '#ECF8F3'
    },
    fonts: {
        poppins: '',
    }
};